﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShapesLibrary;

/**
* 08/26/2020
* CSC-253
* William Merritt
* This program will demo classes, methods, and Math.PI.
* Area Class
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; // Will be our sentry for the do while loop. 
            string inputString; // Will hold our input from the user. 
            
            double p = Math.PI;
            double radius;
            
            int width;
            int length;
            
            double height;
            double circleArea;
            double rectangleArea;
            double cylinderArea;

            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.Write(StandardMessages.GetRadius());
                        inputString = Console.ReadLine();
                        radius = AreaCalculator.ConvertToDouble(ref inputString);
                        circleArea = AreaCalculator.FindArea(ref radius, ref p);
                        Console.WriteLine(StandardMessages.DisplayArea(ref circleArea));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;



                    case "2":
                        Console.Write(StandardMessages.GetWidth());
                        inputString = Console.ReadLine();
                        width = AreaCalculator.ConvertToInt(ref inputString);
                        Console.Write(StandardMessages.GetLength());
                        inputString = Console.ReadLine();
                        length = AreaCalculator.ConvertToInt(ref inputString);
                        rectangleArea = AreaCalculator.FindArea(ref width, ref length);
                        Console.WriteLine(StandardMessages.DisplayArea(ref rectangleArea));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    
                    case "3":
                        Console.Write(StandardMessages.GetRadius());
                        inputString = Console.ReadLine();
                        radius = AreaCalculator.ConvertToDouble(ref inputString);
                        Console.Write(StandardMessages.GetHeight());
                        inputString = Console.ReadLine();
                        height = AreaCalculator.ConvertToDouble(ref inputString);
                        cylinderArea = AreaCalculator.FindArea(ref radius, ref height, ref p);
                        Console.WriteLine(StandardMessages.DisplayArea(ref cylinderArea));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    
                    case "4":
                        Console.WriteLine(StandardMessages.DisplayGoodbye());
                        Console.ReadLine();
                        exit = true;
                        break;

                    
                    default :
                        Console.WriteLine(StandardMessages.DisplayNumError());
                        break;
                }
            }
            while (exit == false);
        }
    }
}
