﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesLibrary
{
    public class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Find area of a circle.\n" +
                 "2. Find the area of a rectangle.\n" +
                 "3. Find the area of a cylinder.\n" +
                 "4. Exit program.\n" +
                 "Please make a choice: "; 
        }

        public static string DisplayNumError() 
        {
            return "Error. Not a valid number.";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day.";        
        }

        public static string CleaningCode() 
        {
            return " ";
        }

        public static string GetRadius() 
        {
            return "Please enter a number for the radius: ";
        }

        public static string GetLength() 
        {
            return "Please enter a number for the length: ";
        }

        public static string GetWidth() 
        {
            return "Please enter a number for the width: ";
        }

        public static string GetHeight() 
        {
            return "Please enter a number for the height: ";
        }

        public static string DisplayArea(ref double input) 
        {
            return $"The area of the this shape is :{input}"; 
        }
    }
}
