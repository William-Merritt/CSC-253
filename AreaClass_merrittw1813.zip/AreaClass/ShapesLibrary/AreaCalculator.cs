﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesLibrary
{
    public class AreaCalculator
    {
        public static double FindArea(ref double radius, ref double p) 
        {
            double area;
            area = p * (radius * radius);
            return area;
        }

        public static int FindArea(ref int width, ref int length)
        {
            int area;
            area = width * length;
            return area;
        }

        public static double FindArea(ref double radius, ref double height, ref double p) 
        {
            double area;
            area = 2 * p * (radius * radius) + radius * (2 * p * height);
            return area;
        }

        public static double ConvertToDouble(ref string inputString) 
        {
            if(double.TryParse(inputString, out double input))
            {
                Console.WriteLine("Input has been added.");
            }
            return input;
        }

        public static int ConvertToInt(ref string inputString)
        {
            if (int.TryParse(inputString, out int input))
            {
                Console.WriteLine("Input has been added.");
            }
            return input;
        }
    }
}
