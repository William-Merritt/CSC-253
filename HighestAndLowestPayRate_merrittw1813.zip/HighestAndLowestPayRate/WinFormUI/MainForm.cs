﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormUI
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void btnMaximumPayRate_Click(object sender, EventArgs e)
        {
            // Declare a varaible to hold the maximum pay rate.
            decimal maxPayRate;

            // Get the maximum pay rate
            maxPayRate = (decimal) this.employeeTableAdapter.MaxPayRate();

            // Display the maximum pay rate
            MessageBox.Show($"The maximum pay rate is: ${maxPayRate}");
        }

        private void btnMinimumPayRate_Click(object sender, EventArgs e)
        {
            // Decalring a variable to hold the minimum pay rate
            decimal minPayRate;

            // Getting the minimum pay rate
            minPayRate = (decimal)this.employeeTableAdapter.MinPayRate();

            // Displaying the minimum pay rate to the user
            MessageBox.Show($"The minimum pay rate is ${minPayRate}");
        }
    }
}
