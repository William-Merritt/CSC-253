﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/*
 * CSC-253  
 * Project- Word Counter
 * William Merritt
 * This program will demo string processing as well as the use of methods.
 * 09/10/2020
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; // Will be our sentry for the do-while loop.
            string inputString; // Will hold our default input for the program.
            int numWords = 0; // Declaring and intializing numWords to be reassigned later.

            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.Write(StandardMessages.GetWords());
                        inputString = Console.ReadLine();
                        numWords = Counter.GetNumberOfWords(inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "2":
                        Console.WriteLine(StandardMessages.DisplayWordCount(numWords));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "3":
                        Console.WriteLine(StandardMessages.DisplayGoodBye());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(StandardMessages.DisplayNumError());
                        break;
                }
            }
            while (exit == false);
        }
    }
}
