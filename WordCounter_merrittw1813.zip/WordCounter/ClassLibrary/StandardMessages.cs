﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    // This class will hold all strings being used in the main program. 
    public class StandardMessages
    {
        // Displays the menu to the user when called.
        public static string DisplayMenu() 
        {
            return "1. Enter any number of words\n" +
                "2. Display word count\n" +
                "3. Exit program\n" +
                "Please Select A Menu Option: ";
        }
        
        // Display an error when the user enters something other than a number for the menu.
        public static string DisplayNumError() 
        {
            return "Error! Incorrect value entered.";
        }

        // Used to clean up the code in the console.
        public static string CleaningCode() 
        {
            return " ";
        }

        // Prompts the user to enter any number of words or phrases.
        public static string GetWords() 
        {
            return "Please enter any number of words: ";
        }


        // Displays the number of words to the user.
        public static string DisplayWordCount(int input) 
        {
            return $"The number of words is ---> {input}";
        }

        // Displays the average number of letters in a string when called. 
        //public static string DisplayNumLetters() 
        //{
        //    return $"The average number of letters is ---> {}";
        //}

        // Displays exit message to the user when called.
        public static string DisplayGoodBye() 
        {
            return "Have a nice day!";
        }
    }
}
