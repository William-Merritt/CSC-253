﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{    
    public static class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter Employee's Information \n2. Display Employee's Information \n3. Display Average Employee Age \n4. Exit Program." +
                "\nPlease Enter a 1/2/3/4 ----> ";
        }

        public static string GetEmployeeFirstName() 
        {
            return "Enter The Employee's first name ----> ";
        }

        public static string GetEmployeeLastName() 
        {
            return "Enter the employee's last name --->";
        }

        public static string GetEmployeePhoneNum() 
        {
            return "Enter The Employee's Phone Number ----> ";
        }

        public static string GetEmployeeAge() 
        {
            return "Enter The Employee's Age ----> ";
        }

        public static string GetEmployeePay() 
        {
            return "Enter the employee's current pay ---> ";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day";
        }


        public static string GetPromotionDate() 
        {
            return "What is the promotion date? ---> ";
        }

        public static string CleaningCode() 
        {
            return " ";
        }

        public static string DisplayMenuError()
        {
            return "Error! Not a valid menu choice!";
        }

        public static string DisplayAgeError()
        {
            return "Must be 16 or older, please re-enter";
        }

    }
}
