﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Manager : Employee
    {
        // Fields
        private string _promotionDate;
        private double _managerPay;
        // Constructors
        public Manager() 
        {
            FirstName = "";
            LastName = "";
            PhoneNumber = "";
            Age = 0;
            PromotionDate = "";
            ManagerPay = 0;
        }

        public Manager(string firstName, string lastName, string phone, int age, string promotionDate, double managerPay) 
                        : base (firstName, lastName, phone, age)       
        {
            PromotionDate = promotionDate;
            ManagerPay = managerPay;

        }
        // Properties 
        public string PromotionDate 
        {
            get 
            {
                return _promotionDate;
            }
            set 
            {
                _promotionDate = value;
            }
        }

        public double ManagerPay 
        {
            get 
            {
                return _managerPay * 5;
            }
            set 
            {
                _managerPay = value;
            }
        }

        // Methods
        public override string AssignEmail()
        {
            return LastName + "@manager.com";
        }
    }
}
