﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class EmployeeMethods
    {
        public static void EnterName(ref string[] name, ref int index, string input)
        { 

            name[index] = input;
            index++;
            Console.WriteLine();
        }

        public static void EnterPhone(ref string[] phone, ref int index, string input) 
        {
            phone[index] = input;
            index++;
            Console.WriteLine();
        }

        public static List<int> EnterAge(List<int> empAge, string input) 
        {
            int number = 0;
            List<int> age = new List<int>();
            age = empAge;

            if (int.TryParse(input, out number))
            {
                age.Add(number);
            }
            else
            {
                StandardMessages.DisplayNumberError();
            }
            Console.WriteLine();

            return age;
        }

        public static void DisplayEmpInfoToUser(string[] name, string[] phone, List<int> age) 
        {
            for (int index = 0; index < age.Count; index++) 
            {
                Console.WriteLine(StandardMessages.DisplayEmployee(name, phone, age, index));
            }
        }

       

     
    }
}
