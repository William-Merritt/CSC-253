﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public static class TryParse
    {
        public static int ParseToInt(string input)
        {
            int output = 0;

            if(int.TryParse(input, out output))
            {
                return output;
            }
            else
            {
                return output;
            }
        }
    }
}
