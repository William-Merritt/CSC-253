﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace EmployeeLibrary
{
    public class BuildEmployee
    {
        public static void BuildAEmployee(List<Employee> inputEmployee) 
        {
            Employee thisEmployee = new Employee();
            bool error = true;

            do
            {
                Console.Write("Enter the name of the employee --->");
                thisEmployee.Name = Console.ReadLine();

                Console.Write("Enter the employee phone number --->");
                thisEmployee.PhoneNum = Console.ReadLine();

                Console.Write("Enter the age of the employee --->");
                thisEmployee.EmpAge = TryParse.ParseToInt(Console.ReadLine());

                if (thisEmployee.EmpAge >= 16)
                {
                    error = true;
                    
                }
                else 
                {
                    Console.WriteLine(StandardMessages.DisplayAgeError());
                    error = false;
                }


            } while (error == true);

            inputEmployee.Add(thisEmployee);
        }

        
    }
}
