﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _firstName;
        private string _lastName;
        private string _phoneNumber;
        private int _age;

        // Constructers
        public Employee()
        {
            FirstName = "";
            LastName = "";
            PhoneNumber = "";
            Age = 0;
        }

        public Employee(string firstName, string lastName, string phone, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            PhoneNumber = phone;
            Age = age;
        }
        // Properties
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        public string LastName 
        {
            get 
            {
                return _lastName;
            }
            set 
            {
                _lastName = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
        public double EmployeePay { get; set; }

        public string FullName 
        {
            get 
            {
                return $"{FirstName} {LastName}";
            }
        }

        // Methods
        public virtual string AssignEmail() 
        {
            return LastName + "@worker.com";
        }
    }
}
