﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;
/**
* 05/11/2020
* CSC 153
* William Merritt
* This program demos base and derived classes..
* Module 6 Test.
*/
namespace ConsoleUI
{
    public static class BuildEmployee
    {
        public static void BuildAEmployee(List<Employee> inputList)
        {

            bool correct = false;

            Employee output = new Employee();

            Console.WriteLine(StandardMessages.GetEmployeeFirstName());
            output.FirstName = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetEmployeeLastName());
            output.LastName = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetEmployeePhoneNum());
            output.PhoneNumber = Console.ReadLine();

            do
            {
                Console.WriteLine(StandardMessages.GetEmployeeAge());
                output.Age = TryParse.ParseToInt(Console.ReadLine());

                if (output.Age >= 16)
                {
                    correct = true;
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayAgeError());
                }

            } while (correct == false);

            Console.WriteLine(StandardMessages.GetEmployeePay());
            output.EmployeePay = TryParse.ParseToInt(Console.ReadLine());

            inputList.Add(output);
        }
    }
}
