﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace ConsoleUI
{
    public static class DisplayEmployee
    {
        public static void DisplayEmployeeInfo(List<Employee> inputList)
        {
            foreach (var employee in inputList)
            {
                Console.WriteLine($"Employee's First Name--> {employee.FirstName}\n " +
                    $"Employee's Last Name---> {employee.LastName}\n" +
                    $"Phone ---> {employee.PhoneNumber}\n" +
                    $"Age ---> {employee.Age}\n" +
                    $"Pay ---> {employee.EmployeePay}\n" +
                    $"Email ---> {employee.AssignEmail()}");
            }
        }

        public static void DisplayManagerInfo(Manager inputManager) 
        {
            Console.WriteLine($"Manager's First Name ---> {inputManager.FirstName}\n" +
                $"Manager's Last Name ---> {inputManager.LastName}\n" +
                $"Promotion Date ---> {inputManager.PromotionDate}\n" +
                $"Phone ---> {inputManager.PhoneNumber}\n" +
                $"Age ---> {inputManager.Age}\n" +
                $"Pay ---> {inputManager.ManagerPay}\n" +
                $"Email ---> {inputManager.AssignEmail()}");
        }

        public static void DisplayAverageAge(List<Employee> inputList)
        {
            int age = 0;
            double average = 0.0;

            foreach (var employe in inputList)
            {
                age += employe.Age;
            }
            average = age / inputList.Count();


            Console.WriteLine(average);
        }
    }
}
