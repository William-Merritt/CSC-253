﻿namespace EmployeeWinForm
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirstName = new System.Windows.Forms.Label();
            this.txtBoxFirstName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtBoxLastName = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtBoxPhoneNum = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtBoxAge = new System.Windows.Forms.TextBox();
            this.lblPay = new System.Windows.Forms.Label();
            this.txtBoxPay = new System.Windows.Forms.TextBox();
            this.btnNewEmployee = new System.Windows.Forms.Button();
            this.lstBoxEmployees = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(12, 9);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(182, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "Enter The Employee\'s first name ----> ";
            // 
            // txtBoxFirstName
            // 
            this.txtBoxFirstName.Location = new System.Drawing.Point(200, 6);
            this.txtBoxFirstName.Name = "txtBoxFirstName";
            this.txtBoxFirstName.Size = new System.Drawing.Size(179, 20);
            this.txtBoxFirstName.TabIndex = 1;
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(12, 36);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(171, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Enter the employee\'s last name --->";
            // 
            // txtBoxLastName
            // 
            this.txtBoxLastName.Location = new System.Drawing.Point(200, 36);
            this.txtBoxLastName.Name = "txtBoxLastName";
            this.txtBoxLastName.Size = new System.Drawing.Size(179, 20);
            this.txtBoxLastName.TabIndex = 3;
            // 
            // lblPhone
            // 
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(12, 66);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(205, 13);
            this.lblPhone.TabIndex = 4;
            this.lblPhone.Text = "Enter The Employee\'s Phone Number ---->";
            // 
            // txtBoxPhoneNum
            // 
            this.txtBoxPhoneNum.Location = new System.Drawing.Point(223, 63);
            this.txtBoxPhoneNum.Name = "txtBoxPhoneNum";
            this.txtBoxPhoneNum.Size = new System.Drawing.Size(181, 20);
            this.txtBoxPhoneNum.TabIndex = 5;
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(12, 95);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(153, 13);
            this.lblAge.TabIndex = 6;
            this.lblAge.Text = "Enter The Employee\'s Age ---->";
            // 
            // txtBoxAge
            // 
            this.txtBoxAge.Location = new System.Drawing.Point(175, 92);
            this.txtBoxAge.Name = "txtBoxAge";
            this.txtBoxAge.Size = new System.Drawing.Size(106, 20);
            this.txtBoxAge.TabIndex = 7;
            // 
            // lblPay
            // 
            this.lblPay.AutoSize = true;
            this.lblPay.Location = new System.Drawing.Point(12, 125);
            this.lblPay.Name = "lblPay";
            this.lblPay.Size = new System.Drawing.Size(225, 13);
            this.lblPay.TabIndex = 10;
            this.lblPay.Text = "What Is The Current Pay For The Employee ->";
            // 
            // txtBoxPay
            // 
            this.txtBoxPay.Location = new System.Drawing.Point(243, 122);
            this.txtBoxPay.Name = "txtBoxPay";
            this.txtBoxPay.Size = new System.Drawing.Size(108, 20);
            this.txtBoxPay.TabIndex = 11;
            // 
            // btnNewEmployee
            // 
            this.btnNewEmployee.Location = new System.Drawing.Point(12, 197);
            this.btnNewEmployee.Name = "btnNewEmployee";
            this.btnNewEmployee.Size = new System.Drawing.Size(327, 34);
            this.btnNewEmployee.TabIndex = 12;
            this.btnNewEmployee.Text = "Submit";
            this.btnNewEmployee.UseVisualStyleBackColor = true;
            this.btnNewEmployee.Click += new System.EventHandler(this.btnNewEmployee_Click);
            // 
            // lstBoxEmployees
            // 
            this.lstBoxEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstBoxEmployees.FormattingEnabled = true;
            this.lstBoxEmployees.ItemHeight = 18;
            this.lstBoxEmployees.Location = new System.Drawing.Point(425, 6);
            this.lstBoxEmployees.Name = "lstBoxEmployees";
            this.lstBoxEmployees.Size = new System.Drawing.Size(327, 220);
            this.lstBoxEmployees.TabIndex = 13;
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 246);
            this.Controls.Add(this.lstBoxEmployees);
            this.Controls.Add(this.btnNewEmployee);
            this.Controls.Add(this.txtBoxPay);
            this.Controls.Add(this.lblPay);
            this.Controls.Add(this.txtBoxAge);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.txtBoxPhoneNum);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.txtBoxLastName);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.txtBoxFirstName);
            this.Controls.Add(this.lblFirstName);
            this.Name = "EmployeeForm";
            this.Text = "EmployeeForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.TextBox txtBoxFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtBoxLastName;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtBoxPhoneNum;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.TextBox txtBoxAge;
        private System.Windows.Forms.Label lblPay;
        private System.Windows.Forms.TextBox txtBoxPay;
        private System.Windows.Forms.Button btnNewEmployee;
        private System.Windows.Forms.ListBox lstBoxEmployees;
    }
}