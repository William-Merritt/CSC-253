﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;
using ConsoleUI;

namespace EmployeeWinForm
{
    public partial class EmployeeForm : Form
    {
        //Creating an empty list to hold new employees. 
        public List<Employee> employee = new List<Employee>();
        public EmployeeForm()
        {
            InitializeComponent();
            //Testing button options
            btnNewEmployee.BackColor = Color.Azure;
        }

        private void btnNewEmployee_Click(object sender, EventArgs e)
        {
            //Clearing the list box before displaying the new employee names
            lstBoxEmployees.Items.Clear();

            //Checking to make sure the employee is over the age of 16.
            if (int.Parse(txtBoxAge.Text) > 16)
            {
                //Adding new employees information to the employee list. Must use .text to utilize string inside of text boxes.
                employee.Add(new Employee
                {
                    FirstName = txtBoxFirstName.Text,
                    LastName = txtBoxLastName.Text,
                    PhoneNumber = txtBoxPhoneNum.Text,
                    Age = int.Parse(txtBoxAge.Text),
                    EmployeePay = double.Parse(txtBoxPay.Text)
                });
            }
            else 
            {
                MessageBox.Show("Error! The employee must be over the age of 16!");
            }
            //Creating a loop to display all employees created once the submit button is clicked. 
            foreach (var item in employee)
            {
                lstBoxEmployees.Items.Add(item.FullName);
            }
            
        }


    }
}
