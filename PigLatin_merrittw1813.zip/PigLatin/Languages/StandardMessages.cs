﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Languages
{
    public class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter a word/sentence/name\n" +
                "2. Exit program\n" +
                "Please enter a choice 1/2---> ";
        }

        public static string PromptForString() 
        {
            return "Please enter a word/sentence/name: ";
        }

        public static string DisplayEnglish(string input) 
        {
            return $"English: {input}";
        }

        public static string DisplayPigLatin(string input) 
        {
            return $"Pig Latin: {input}";
        }

        public static string DisplayNumError() 
        {
            return "Error! Incorrect value entered.";
        }

        public static string DisplayExitMsg() 
        {
            return "Have a nice day!";
        }

        public static string CleaningCode() 
        {
            return " ";
        }
    }
}
