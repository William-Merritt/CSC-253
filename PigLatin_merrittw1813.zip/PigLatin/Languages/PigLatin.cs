﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Languages
{
    public class PigLatin
    {
        public static string ConvertToPigLatin(string input) 
        {
            const string VOWELS = "AEIOUaeiou"; // Used to compare characters of first character
            List<string> piglatin = new List<string>(); // To hold all the new words in a list to display later

            input.Trim(); // Taking the string and getting rid of all whitespace before looking at each word.

            string[] tokens = input.Split(null); // Passing null to split to get rid of all whitespace 

 

            foreach (string element in tokens) // For each element in tokens get the first letter and compare it to vowels.
            {
                string firstChar = element.Substring(0, 1); 
                string remainingChar = element.Substring(1, element.Length - 1);
                int compareChar = VOWELS.IndexOf(firstChar);

                if (compareChar == -1)
                {
                    piglatin.Add(remainingChar += firstChar + "ay");
                }
                else 
                {
                    piglatin.Add(element + "ay");
                }

            }
            return string.Join(" ", piglatin);
        }
    }
}
