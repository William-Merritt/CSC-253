﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Languages;

/*
 * CSC-253
 * WILLIAM MERRITT
 * PROJECT NAME --> PIG LATIN
 * THIS PROGRAM WILL DEMO THE USE OF STRING PROCESSING AND CHARACTERS.
 * 09/20/2020
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; // To act as our sentry for the do while loop
            string inputString; // To hold all of our input to be saved later.

            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.WriteLine(StandardMessages.PromptForString());
                        inputString = Console.ReadLine();
                        string newLanguage = PigLatin.ConvertToPigLatin(inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        Console.WriteLine(StandardMessages.DisplayEnglish(inputString));
                        Console.WriteLine(StandardMessages.DisplayPigLatin(newLanguage));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "2":
                        Console.WriteLine(StandardMessages.DisplayExitMsg());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(StandardMessages.DisplayNumError());
                        break;
                }
            }
            while (exit == false);
        }
    }
}
