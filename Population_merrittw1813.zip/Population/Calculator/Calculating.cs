﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    // This class will hold all calculations and conversions being used in the main program. 
    public static class Calculating
    {
        // Converting string to double to be used later in the main program. 
        public static double ConvertingString(ref string inputString) 
        {
            if (double.TryParse(inputString, out double initPopulation)) 
            {
                Console.WriteLine("Input has been added.");
            }
            return initPopulation;
        }

        // Converting growth rate in to a percent.
        public static double ConvertToPercent(ref double input) 
        {
            return input / 100;
        }

        // The method will be used to calculate the final population and add it to a list.
        public static List<double> GetPercentIncrease(ref double initPop, ref double growthRate, ref double numDays) 
        {
            double time = 0; // Sentry for the while loop.
            
            // Creating an empty list to add the final population to the list. 
            List<double> population = new List<double>();
            
            while (time < numDays + 1) 
            {
                double finalPop = (1 + growthRate) * initPop * time;
                population.Add(finalPop);
                time++; //Iterating time to eventually end the loop where the user wants it. 
            }
            return population;
        }


    }
}
