﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;
/**
* 08/26/2020
* CSC-253
* William Merritt
* This program will find the final population of bacteria after 10 days. Output will be displayed in a table
* This program will also demo loops, variables, and operations. 
* Population (Bacteria Population)
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; //This will be used a sentry for a while loop.
            
            string inputString; //To hold the users input for the formula.
            
            double initPopulation = 0; //Initializing population to use later in the formula
            double finalGrowthRate = 0; //Initializing finalGrowthRate to hold growth rate
            double numDays = 0;
            
            List<double> bacteria = new List<double>();
            
            do
            {
                // Calls the display menu method the prompt the user to enter a menu choice.
                Console.Write(StandardMessages.DisplayMenu());

                //Take the user choice and pass it through the switch statement.
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.Write(StandardMessages.GetInitialPopulation());
                        inputString = Console.ReadLine(); // Using input string to hold user input. 
                        initPopulation = Calculating.ConvertingString(ref inputString); // Converting user input into a double.
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "2":
                        Console.Write(StandardMessages.GetGrowthRate());
                        inputString = Console.ReadLine();
                        double growthRate = Calculating.ConvertingString(ref inputString);
                        finalGrowthRate = Calculating.ConvertToPercent(ref growthRate);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "3":
                        Console.Write(StandardMessages.GetNumDays());
                        inputString = Console.ReadLine();
                        numDays = Calculating.ConvertingString(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;


                    case "4":
                        bacteria = Calculating.GetPercentIncrease(ref initPopulation, ref finalGrowthRate, ref numDays);
                        StandardMessages.DisplayTable(ref bacteria);
                        break;

                    case "5":
                        Console.WriteLine(StandardMessages.DisplayGoodbye());
                        exit = true;
                        break;
                }
            }
            while (exit == false);
        }
    }
}
