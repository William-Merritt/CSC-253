﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessages
    {
        // Displaying the menu to the user. Options will be used in a switch statement.
        public static string DisplayMenu() 
        {
            return "1. Input Initial Populaiton\n2. Input Growth Rate\n3. Enter Number Of Days" +
                "\n4. Display Final Population\n5. Exit Program\nPlease choose an option: ";
        }
        // Getting the initial bacteria population from the user.
        public static string GetInitialPopulation() 
        {
            return "Please enter the initial population of bacteria: ";
        }
        // Getting the initial growth rate of bacteria from the user. 
        public static string GetGrowthRate() 
        {
            return "Please enter the growth rate of bacteria: ";
        }
        
        // Getting the days of growth from the user.
        public static string GetNumDays() 
        {
            return "Please enter the number of days for growth period: ";
        }
        // Display final message to the user. 
        public static string DisplayGoodbye() 
        {
            return "Have a nice day!";
        }

        // Method is used to create space between user choice and the menu.
        public static string CleaningCode() 
        {
            return "";
        }

        // Method to display the list of information to the user. 
        public static void DisplayTable(ref List<double> bacteria)
        {
            Console.WriteLine("Displaying the list of bacteria growth...");
            Console.WriteLine("Days\t\tPopulaiton\n" +
                "==========================");
            foreach (var item in bacteria) // foreach loop is used to loop through a list and read information. 
            {
                Console.WriteLine($"{bacteria.IndexOf(item)}\t\t{item}");
            }
            Console.ReadLine();
        }
        
    }
}
