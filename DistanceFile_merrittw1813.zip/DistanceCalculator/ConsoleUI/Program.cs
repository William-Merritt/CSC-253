﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;
using System.IO; // Must use System.IO when using the classes Streamwriter and StreamReader

/**
 * THIS PROGRAM WILL BE OUR BASE FOR THE STREAMWRITER PROGRAM LATER. DEMOS METHODS AND DECISION STRUCTURES.
 * CSC-253
 * WILLIAM MERRITT
 * PROJECT NAME ---> DISTANCE TRAVELED
 * 09/23/2020
 */


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; // Used as a sentry for our do-while.
            string inputString; // Will hold input from the user.
            double speed = 0;// Initializing speed for later.
            double time = 0;// Initializing time for later
            double distanceTraveled = 0; // Initialzing distanceTraveled for later.

            do
            {

                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.WriteLine(StandardMessages.PromptForSpeed());
                        inputString = Console.ReadLine();
                        speed = FindDistanceTraveled.ConvertToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode()); // Used to space out the console code.
                        break;

                    case "2":
                        Console.WriteLine(StandardMessages.PromptForTime()); 
                        inputString = Console.ReadLine();
                        time = FindDistanceTraveled.ConvertToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "3":
                        try // Always use try-catch when creating a file to catch any exceptions thrown during file creation.
                        {
                            StreamWriter outputFile; // Creating a steamwriter variable to refernce the object.
                            outputFile = File.CreateText("Distance.txt"); // Creating a new text file named Distance.
                            distanceTraveled = FindDistanceTraveled.GetDistance(speed, time);
                            outputFile.WriteLine(StandardMessages.DisplayDistanceTraveled(speed, time, distanceTraveled)); //Changed Console.WL to outputFile.WL.
                            outputFile.WriteLine(StandardMessages.CleaningCode());
                            outputFile.Close(); // Must always close the file to avoid any exceptions in the code.
                            Console.WriteLine(StandardMessages.DisplayFileConfirmation()); // Giving the user confirmation that the information has been written to a file.
                            Console.WriteLine(StandardMessages.CleaningCode());
                        }
                        catch (Exception ex) 
                        {
                            Console.WriteLine(ex.Message); // Displaying an error in case the file is not created correctly.
                        }
                        break;

                    case "4":
                        Console.WriteLine(StandardMessages.DisplayExitMessage());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:

                        break;
                }
            }
            while (exit == false);
        }
    }
}
