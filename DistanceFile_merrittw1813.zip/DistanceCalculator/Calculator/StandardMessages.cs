﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class StandardMessages
    {
        public static string PromptForSpeed() 
        {
            return "How fast was the vehicle moving: ";
        }

        public static string PromptForTime() 
        {
            return "How long have you been traveling: ";
        }

        public static string DisplayError() 
        {
            return "Error! Invalid value entered.";
        }

        public static string DisplayFileError() 
        {
            return "Oops! Something went wrong with the file.";
        }

        public static string DisplayMenu() 
        {
            return "1. Enter vehicle's speed\n" +
                "2. Enter amount of time traveled\n" +
                "3. Display distance traveled\n" +
                "4. Exit program\n" +
                "Select a menu option: ";
        }

        public static string DisplayExitMessage() 
        {
            return "Have a nice day.";
        }

        public static string DisplayDistanceTraveled(double speed, double time, double distanceTraveled) 
        {
            return $"Time traveled: {time} hours\n" +
                $"Miles per hour: {speed} mph\n" +
                $"Distance traveled: {distanceTraveled} miles";
        }

        public static string CleaningCode() 
        {
            return " ";
        }

        public static string DisplayFileConfirmation() 
        {
            return "Done. New file created.";
        }

    }
}
