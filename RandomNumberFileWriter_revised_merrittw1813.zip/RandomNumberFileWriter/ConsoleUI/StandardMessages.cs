﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class StandardMessages
    {
        public static string PromptForNumAmt() 
        {
            return "How many random numbers should be added to the file: ";
        }

        public static string PromptForFileName() 
        {
            return "What would you like this file to be named: ";
        }

        public static string DisplayFileEnd() 
        {
            return "Done!";
        }
    }
}
