﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Converter;

/**
 * CSC-253
 * William Merritt
 * 10/01/2020
 * Project -> Write numbers to a file and get user input
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string inputString;                         //To hold all input from the user as string.
                StreamWriter outputFile;                    //Creating a new StreamWriter object.
                Random rand = new Random();                 //Instantiating a new random object.

                Console.Write(StandardMessages.PromptForFileName());
                outputFile = File.CreateText(Console.ReadLine()+".txt");
                Console.Write(StandardMessages.PromptForNumAmt());
                inputString = Console.ReadLine();
                int userAmt = StringConverter.ConvertToInt(inputString);

                for (int element = 0; element <= userAmt - 1; element++) 
                {
                    outputFile.WriteLine(rand.Next(1, 101));
                }

                outputFile.Close();                                     //Close the file when working with StreamWriter
                Console.WriteLine(StandardMessages.DisplayFileEnd());   //Letting the user know the file is completed.
                Console.ReadLine();
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

        }
    }
}
