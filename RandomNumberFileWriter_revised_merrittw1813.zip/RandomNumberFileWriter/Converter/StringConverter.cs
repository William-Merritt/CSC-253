﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Converter
{
    public static class StringConverter
    {

        // Creating a method the converts string to int to be used in comparisons. 
        public static int ConvertToInt(string inputString) 
        {
            if (int.TryParse(inputString, out int input)) 
            {
                Console.WriteLine("Amount has been saved.");
            }
            return input;
        }
    }
}
