﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
 * CSC-253
 * William Merritt 
 * Project Name --> Random Number File Reader
 * This program will demo StreamReader. 
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string inputString;                     //Declare a variable for user input
            int numCount = 0;                       //To hold the number of random numbers
            int totalOfNumbers = 0;                 //To hold the sum of all the numbers
            int number;                             //To hold the number being passed

            
            //Creating a try-catch to catch any exceptions when using system.io
            try
            {
                //Declare a StreamReader variable
                StreamReader inputFile;

                //Prompt the user for the file path
                Console.WriteLine("What is the path to the file, without the file name? ");
                Console.Write("Path: ");
                
                //Save the user input
                string filePath = Console.ReadLine();

                //Prompt the user for the file name.
                Console.WriteLine("What is the name of the file: ");
                Console.Write("File Name: ");

                //Assign the user input to inputString.
                inputString = Console.ReadLine();

                //Open the file and get a StreamReader Object.
                inputFile = File.OpenText($@"{filePath}\{inputString}" + ".txt");

                //Take the file and read through it until the end
                while (!inputFile.EndOfStream)
                {

                    //Get the total of the numbers
                    number = int.Parse(inputFile.ReadLine());

                    //Display all the numbers
                    Console.WriteLine(number);

                    //Add that number to total numbers
                    totalOfNumbers += number;

                    //Iterate the count
                    numCount++;
                }

                //Close the file after using it.
                inputFile.Close();

                //Display the total of the numbers to the user
                Console.WriteLine($"The total of all the numbers is: {totalOfNumbers}");

                //Display the count of random numbers
                Console.WriteLine($"The number of random numbers in the file is: {numCount}");

                //Using Console.RL() to keep the console open so that the user can see their results.
                Console.ReadLine();


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }
    }
}
