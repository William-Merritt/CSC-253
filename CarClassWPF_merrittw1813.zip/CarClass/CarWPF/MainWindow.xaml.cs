﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CarClassLibrary;
using ConsoleUI;

namespace CarWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Creating a new list
        public List<Car> cars = new List<Car>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmitInfo_Click(object sender, RoutedEventArgs e)
        {
            //Clearing the information from the listbox before adding a new user
            lstBoxCars.Items.Clear();

            //Adding the new object to a new list called cars. Then adding an if statement for the year.
            if (BuildCar.ConvertToInt(txtBoxCarYear.Text) > 0)
            {
                cars.Add(new Car
                {
                    CarMake = txtBoxCarMake.Text,
                    CarYear = BuildCar.ConvertToInt(txtBoxCarYear.Text)
                });
            }
            else 
            {
                MessageBox.Show(StandardMessages.DisplayNumError());
            }

            //Creating a loop to display all cars in the new list
            foreach (var element in cars) 
            {
                lstBoxCars.Items.Add(element.YearMake);
            }
        }
    }
}
