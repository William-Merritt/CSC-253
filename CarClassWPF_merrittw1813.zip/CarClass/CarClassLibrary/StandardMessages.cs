﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public static class StandardMessages
    {
        //Creating the main menu
        public static string DisplayMenu() 
        {
            return "1. Create Car\n2. Accelerate\n3. Brake\n4. Exit Program";
        }

        //Creating validation for the menu choice
        public static string DisplayNumError() 
        {
            return "Error! Incorrect number entered.";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day.";
        }

        public static string DisplayCarObject(Car yourCar) 
        {
            return $"Car Year ---> {yourCar.CarYear}, Car Make ---> {yourCar.CarMake}";
        }

        public static string CleaningCode() 
        {
            return "";
        }
    }
}
