﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLibrary
{
    public class Car
    {
        // Fields
        private int _carYear;
        private string _carMake;
        private int _carSpeed;

        // Constructors
        public Car() 
        {
            CarYear = 0;
            CarMake = "";
            CarSpeed = 0;
        }

        public Car(int carYear, string carMake, int carSpeed) 
        {
            CarYear = carYear;
            CarMake = carMake;
            CarSpeed = carSpeed;
        }

        // Properties
        public int CarYear 
        {
            get 
            {
                return _carYear;
            }
            set 
            {
                _carYear = value;
            }
        }

        public string CarMake 
        {
            get 
            {
                return _carMake;
            }
            set 
            {
                _carMake = value;
            }
        }

        public int CarSpeed 
        {
            get 
            {
                return _carSpeed;
            }
            set 
            {
                _carSpeed = value;
            }
        }

        public string YearMake 
        {
            get 
            {
                return $"{_carMake} {_carYear}";
            }
        }

        // Methods
        public void Accelerate()
        {
            Console.WriteLine(StandardMessages.CleaningCode());
            Console.WriteLine($"Current Speed is --> {_carSpeed}");
            Console.WriteLine(StandardMessages.CleaningCode());
            Console.WriteLine("Accelerating.");
            
            if (_carSpeed <= 120)
            {
                _carSpeed += 5;
            }
            else
            {
                Console.WriteLine(StandardMessages.CleaningCode());
                Console.WriteLine($"You're currently going the max speed.");
            }
            
        }

        public void Brake() 
        {
            Console.WriteLine(StandardMessages.CleaningCode());
            Console.WriteLine($"Current Speed is ---> {_carSpeed}");
            Console.WriteLine(StandardMessages.CleaningCode());
            Console.WriteLine("Braking.");
            
            if (_carSpeed >= 5)
            {
                _carSpeed -= 5;
            }
            else 
            {
                Console.WriteLine(StandardMessages.CleaningCode());
                Console.WriteLine($"The car is stopped, {_carMake} cannot go any slower.");
            }
            
        }


    }
}
