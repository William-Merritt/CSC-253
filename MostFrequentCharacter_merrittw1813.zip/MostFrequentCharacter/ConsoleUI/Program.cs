﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/*
 * CSC-253
 * William Merritt
 * Project Name -> Most Frequent Character
 * This project will demo string processing and loops.
 * Date -> 09/20/2020
 */


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            string inputString;
            char frequentChar;

            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.WriteLine(StandardMessages.PromptForSentence());
                        inputString = Console.ReadLine();
                        frequentChar = Counter.DisplayFrequentChar(inputString);
                        Console.WriteLine(StandardMessages.DisplayFreqCharacter(frequentChar));
                        break;

                    case "2":
                        Console.WriteLine(StandardMessages.DisplayExitMessage());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(StandardMessages.DisplayNumError());
                        break;
                }


            } while (exit == false);

        }
    }
}
