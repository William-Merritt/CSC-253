﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Counter
{
    public class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter a sentence\n" +
                "2. Display most frequent character\n" +
                "3. Exit program";
        }

        public static string PromptForSentence() 
        {
            return "Enter a sentence/name/word --> ";
        }

        public static string DisplayFreqCharacter() 
        {
            return $"The most frequent character is {}";
        }

        public static string CleaningCode() 
        {
            return "";
        }

        public static string DisplayNumError() 
        {
            return "Error! Incorrect value entered.";
        }

        public static string DisplayExitMessage() 
        {
            return "Have a nice day.";
        }
    }
}
