﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {   
            public static string DisplayMenu()
            {
                return "1. Enter a sentence\n" +
                    "2. Exit program\n" +
                    "Enter a choice --> ";
            }

            public static string PromptForSentence()
            {
                return "Enter a sentence/name/word --> ";
            }

            public static char DisplayFreqCharacter(char input)
            {
                Console.Write("The most frequent character is --> ");
                return input;
            }

            public static string CleaningCode()
            {
                return "";
            }

            public static string DisplayNumError()
            {
                return "Error! Incorrect value entered.";
            }

            public static string DisplayExitMessage()
            {
                return "Have a nice day.";
            }
        
    }
}
