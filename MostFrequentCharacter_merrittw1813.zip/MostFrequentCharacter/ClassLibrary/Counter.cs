﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Counter
    {
        public static char DisplayFrequentChar(string input) 
        {
            const int ASCII_SIZE = 256; //Setting the array size to 256 using the same number of characters in ASCII
            char frequentChar = ' '; // To hold the character passed in to the array
            int minimumCount = -1;// Setting the minimum amount the character has to meet.

            int[] count = new int[ASCII_SIZE]; // Passes 256 

            int strLength = input.Length; // Creating a variable to hold the strings length.

            for (int element = 0; element < strLength; element++) 
            {
                count[input[element]]++; // Counting each element as it's passed into the array.
            }

            for (int element = 0; element < strLength; element++) 
            {
                if (minimumCount < count[input[element]]) 
                {
                    minimumCount = count[input[element]];
                    frequentChar = input[element];
                }
            }

            return frequentChar;
        }
    }
}
