﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class FindDistanceTraveled
    {
        // Converting string to double to be used for math later in the program.
        public static double ConvertToDouble(ref string inputString)
        {
            if (double.TryParse(inputString, out double input)) 
            {
                Console.WriteLine("Input has been converted");
            }
            return input;
        }


        // Using the converted string to find the distance of speed. Passing speed and time as refernce. 
        public static double GetDistance(double speed, double time) 
        {
            double distance = speed * time;

            return distance;
        }
    }
}
