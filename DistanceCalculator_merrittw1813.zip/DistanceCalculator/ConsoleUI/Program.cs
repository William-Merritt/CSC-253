﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;

/**
 * THIS PROGRAM WILL BE OUR BASE FOR THE STREAMWRITER PROGRAM LATER. DEMOS METHODS AND DECISION STRUCTURES.
 * CSC-253
 * WILLIAM MERRITT
 * PROJECT NAME ---> DISTANCE TRAVELED
 * 09/23/2020
 */


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false; // Used as a sentry for our do-while.
            string inputString; // Will hold input from the user.
            double speed = 0;// Initializing speed for later.
            double time = 0;// Initializing time for later
            double distanceTraveled = 0; // Initialzing distanceTraveled for later.

            do
            {

                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.WriteLine(StandardMessages.PromptForSpeed());
                        inputString = Console.ReadLine();
                        speed = FindDistanceTraveled.ConvertToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode()); // Used to space out the console code.
                        break;

                    case "2":
                        Console.WriteLine(StandardMessages.PromptForTime()); 
                        inputString = Console.ReadLine();
                        time = FindDistanceTraveled.ConvertToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "3":
                        Console.WriteLine(StandardMessages.CleaningCode());
                        distanceTraveled = FindDistanceTraveled.GetDistance(speed,time);
                        Console.WriteLine(StandardMessages.DisplayDistanceTraveled(speed, time, distanceTraveled));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "4":
                        Console.WriteLine(StandardMessages.DisplayExitMessage());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:

                        break;
                }
            }
            while (exit == false);
        }
    }
}
