﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator;
using Xunit;

namespace DemoLibrary.Tests
{
    public class CalculatorTests
    {
        [Theory]            //Allows us to pass in data from different data sets using InlineData.
        [InlineData(20, 10, 22)]
        [InlineData(5, 15, 5.75)]
        public void CalculateRetail_UserValuesShouldReturnRetailCost(double x, double y, double expected)
        {
            // Arrange - arranging values

            // Act - do the action that is being tested
            double actual = CalculatingCost.CalculateRetail(x, y);

            // Assert - testing our expect and our actual value
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData("10", 10)]
        [InlineData("25", 25)]
        public void ConvertingString_StringWholeSaleShouldConvertToDouble(string x, double expected)
        {
            // Arrange
            // Act
            double actual = CalculatingCost.ConvertingWholeSale(ref x);

            // Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData("50", 50)]
        [InlineData("100", 100)]
        [InlineData("-1", -1)]
        public void ConvertingString_StringMarkupShouldConvertToDouble(string x, double expected) 
        {
            //Arrange
            //Act
            double actual = CalculatingCost.ConvertingMarkup(ref x);

            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
