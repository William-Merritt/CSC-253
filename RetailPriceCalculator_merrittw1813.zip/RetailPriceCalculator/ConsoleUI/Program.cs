﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 02/20/2020
* CSC 153
* William Merritt
* This program will take the wholesale cost and markup percentage and give the customer the retail cost
* Of a product of their choosing. (Revised)
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
           
            bool exit = false;
            double wholeSaleCost = 0;
            double percentage = 0;
            do
            {
                //Displaying the Main Menu to the user
                StandardMessage.DisplayMainMenu();
                string input = Console.ReadLine();

                //Getting the User's input
                

                switch (input)
                {
                    case "1":
                        StandardMessage.AskForWholesale();
                        string cost = Console.ReadLine();
                        wholeSaleCost = Calculator.CalculatingCost.ConvertingWholeSale(ref cost);
                        StandardMessage.CleaningCode();
                        break;

                    case "2":
                        StandardMessage.AskForMarkup();
                        string markup = Console.ReadLine();
                        percentage = Calculator.CalculatingCost.ConvertingMarkup(ref markup);
                        StandardMessage.CleaningCode();
                        break;

                    case "3":
                        double display = Calculator.CalculatingCost.CalculateRetail(wholeSaleCost, percentage);
                        StandardMessage.DisplayCost(ref display);
                        StandardMessage.CleaningCode();
                        break;

                    case "4":
                        StandardMessage.DisplayGoodbye();
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        StandardMessage.DisplayNumberError();
                        Console.ReadLine();
                        StandardMessage.CleaningCode();
                        break;


                }
            } while (exit == false);
        }

      

        


    }
}
