﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    // This class will hold the methods used in the main program.
    public class Counter
    {
        // This method will take a string as input and return the number of words in the string.
        public static int GetNumberOfWords(string input) 
        {
            string[] tokens = input.Split(null); // Creating an array to hold the elements of the string.
            // .Split extracts tokens from a string and returns them as an array of strings. 

            return tokens.Length; // Returning the length of the array or in this case the number of words.
        }

        // This method will take a string as input and return the average number of letters in each word.
        public static int GetNumOfLetters(string input) 
        {
            int total = 0;

            foreach (char letter in input) 
            {
                total++;
            }

            return total;


        }

        public static int GetAvgNumLetters(ref int numWords, ref int totalLetters) 
        {
            int avgOfLetters = totalLetters / numWords;

            return avgOfLetters;
        }
    }
}
