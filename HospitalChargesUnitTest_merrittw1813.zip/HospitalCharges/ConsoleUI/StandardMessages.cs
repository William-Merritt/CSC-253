﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    // Class to hold all standard messages. 
    public static class StandardMessages
    {
        // Display a menu to the user.
        public static string DisplayMenu() 
        {
            return "1. Enter the number of days spent in the hospital.\n" +
                "2. Enter the amount of medication charges.\n" +
                "3. Enter the amount of surgical charges.\n" +
                "4. Enter the amount of lab fees.\n" +
                "5. Enter the amount of physical rehabilitation charges.\n" +
                "6. Display total cost of hospital visit.\n" +
                "7. Exit the program.\n" +
                "Please select a menu choice: ";
        }

        // Get number of days in hospital from the user.
        public static string GetNumDays() 
        {
            return "Please enter how many days you spent in the hospital: ";
        }

        // Get the amount of medication charges.
        public static string GetMedCost() 
        {
            return "Please enter the amount spent on medication: ";
        }

        // Get the amount of surgical charges 
        public static string GetSurgicalCost() 
        {
            return "Please enter the amount spent on surgery: ";
        }

        // Get the amount of lab fees.
        public static string GetLabCost() 
        {
            return "Please enter the amount spent on lab fees: ";
        }

        // Get the amount spent on physcial rehabilitation charges.
        public static string GetRehabCost() 
        {
            return "Please enter the amount spent on physical rehabilitation: ";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day!";
        }

        public static string DisplayCharges(ref double finalCost, ref double baseCost, 
            ref double miscCost) 
        {
            return $"The base cost for your visit is ${baseCost}\n" +
                $"The miscellaneous cost for your visit is ${miscCost}\n" +
                $"The total cost of your stay is ${finalCost}";
        }

        public static string DisplayNumError() 
        {
            return "Error. Incorrect value entered.";
        }

        public static string CleaningCode() 
        {
            return "";
        }
    }
}
