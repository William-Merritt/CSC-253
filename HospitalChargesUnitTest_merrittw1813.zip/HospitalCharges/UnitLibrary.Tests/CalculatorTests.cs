﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalCalculator;
using Xunit;

namespace UnitLibrary.Tests
{
    public class CalculatorTests
    {
        // Creating the first test using Theory.
        [Theory]
        [InlineData(10, 3500)]
        [InlineData(22, 7700)]
        public void CalculateStayCharges_SimpleValuesShouldMultiply(double input, double expected)
        {
            //Arrange

            //Actual
            double actual = Calculator.CalcStayCharges(ref input);
            //Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData(10, 20, 30, 40, 100)]
        [InlineData(22, 34, 55, 60, 171)]
        public void CalculateMiscCharges_SimpleValuesShouldAdd(double w, double x, double y, double z, double expected)
        {
            //Arrange

            //Actual
            double actual = Calculator.CalcMiscCharges(ref w, ref x, ref y, ref z);

            //Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData(10, 30, 40)]
        [InlineData(88, 11, 99)]
        [InlineData(2.5, 11.3, 13.8)]
        public void CalculateTotalCharges_SimpleValuesShouldAdd(double x, double y, double expected)
        {
            //Arrange

            //Actual
            double actual = Calculator.CalcTotalCharges(ref x, ref y);
            
            //Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData("10", 10)]
        [InlineData("1.5", 1.5)]
        public void ConvertStringToDouble_StringShouldConvertToDouble(string input, double expected) 
        {
            //Arrange

            
            //Actual
            double actual = Calculator.ConvertStringToDouble(ref input);
            
            //Assert
            Assert.Equal(expected, actual);
        }
    }
}
