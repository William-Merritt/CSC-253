﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalCalculator
{
    public static class Calculator
    {
        // Converting string to double
        public static double ConvertStringToDouble(ref string inputString) 
        {
            if(double.TryParse(inputString, out double input)) 
            {
                Console.WriteLine("Input has been added.");
            }
            return input;
        }

        // Calculates and returns the base charges for the hospital stay.
        public static double CalcStayCharges(ref double daysSpent) 
        {
            return daysSpent * 350;
        }

        // Calcualtes and returns the total of medication, surgical, lab, and rehab cost.
        public static double CalcMiscCharges(ref double medsCost, ref double surgicalCost, 
            ref double labCost,  ref double rehabCost) 
        {
            return medsCost + surgicalCost + labCost + rehabCost;
        }

        // Calculates and returns the total charges.
        public static double CalcTotalCharges(ref double baseCost, ref double miscCost) 
        {
            return baseCost + miscCost;
        }
    }
}
