﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalCalculator;

/**
* 08/26/2020
* CSC-253
* William Merritt
* This program will demo methods, operators, and return statements.
* Hospital Charges
*/

namespace ConsoleUI
{
    class Program
    {

        static void Main(string[] args)
        {
            // Variables

            bool exit = false; //Will be used as sentry for our do-while loop.
            string inputString; //Will be used as a default holder for data/charges. 
            double daysSpent = 0; //Will hold days spent in the hospital
            double medsCost = 0; //Will hold cost of medication
            double surgicalCost = 0; //Will hold cost of surgical operations
            double labCost = 0;//Will hold cost of labs
            double rehabCost = 0;//Will hold cost of physical rehabilitation. 

            // Creating the start of the do-while loop.
            do
            {
                Console.Write(StandardMessages.DisplayMenu());

                switch (Console.ReadLine()) 
                {
                    case "1":
                        Console.Write(StandardMessages.GetNumDays()); 
                        inputString = Console.ReadLine();//Get input from the user and save  it to inputString
                        daysSpent = Calculator.ConvertStringToDouble(ref inputString);//Convert String to Double
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "2":
                        Console.Write(StandardMessages.GetMedCost());
                        inputString = Console.ReadLine();
                        medsCost = Calculator.ConvertStringToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "3":              
                        Console.Write(StandardMessages.GetSurgicalCost());
                        inputString = Console.ReadLine();
                        surgicalCost = Calculator.ConvertStringToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "4":
                        Console.Write(StandardMessages.GetLabCost());
                        inputString = Console.ReadLine();
                        labCost = Calculator.ConvertStringToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "5":
                        Console.Write(StandardMessages.GetRehabCost());
                        inputString = Console.ReadLine();
                        rehabCost = Calculator.ConvertStringToDouble(ref inputString);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "6":
                        Console.WriteLine(StandardMessages.CleaningCode());
                        double baseCost = Calculator.CalcStayCharges(ref daysSpent);
                        double miscCost = Calculator.CalcMiscCharges(ref medsCost, ref surgicalCost, ref labCost, ref rehabCost);
                        double finalCost = Calculator.CalcTotalCharges(ref baseCost, ref miscCost);
                        Console.WriteLine(StandardMessages.DisplayCharges(ref finalCost, ref baseCost, ref miscCost));
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "7":
                        Console.WriteLine(StandardMessages.CleaningCode());
                        Console.Write(StandardMessages.DisplayGoodbye());
                        Console.ReadLine();
                        exit = true;
                        break;

                    default:
                        Console.WriteLine(StandardMessages.DisplayNumError());
                        break;
                }
            }
            while (exit == false);
        }
    }
}
